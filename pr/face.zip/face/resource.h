//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FaceDetect.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FACEDETECT_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_REPLACE              129
#define IDC_BMPSHOW                     1000
#define IDC_BTN_OPENFILE                1001
#define IDC_BTN_LIKEHOOD                1002
#define IDC_BTN_BINARY                  1003
#define IDC_BTN_HISTOGRAM_V             1004
#define IDC_BTN_HISTOGRAM_H             1005
#define IDC_BTN_MARK_FACE_1             1006
#define IDC_BTN_FACEHAIR                1007
#define IDC_BTN_HISTOGRAM_FACE          1008
#define IDC_BTN_HISTOGRAM_HAIR          1009
#define IDC_BTN_MARK_FACE_2             1010
#define IDC_BTN_EDGE                    1011
#define IDC_BTN_MARK_EYE                1012
#define IDC_BTN_MARK_MOUSE              1013
#define IDC_BTN_MARK_NOSE               1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
