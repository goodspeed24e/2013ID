// Store.cpp : implementation file
//

#include "stdafx.h"
#include "pattern.h"
#include "Store.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Store




BEGIN_MESSAGE_MAP(Store, CEdit)
	//{{AFX_MSG_MAP(Store)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Store message handlers
