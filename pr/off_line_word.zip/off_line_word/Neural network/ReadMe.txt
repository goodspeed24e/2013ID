
Program:    ONR - Optical Number Recognizor
Author:     James Matthews
Date:       21/4/2001
Version:    1.11

===============================
       V e r s i o n s
===============================

v1.11
- Fixed a problem caused by VC6 Professional Edition optimizations.
  Basically, the program wouldn't work when "Maximum Speed" or
  "Minimum Size" options were enabled. The program uses #pragra
  statements to disable optimizations for the perceptron code.

v1.1
- Small GUI tweaks - slightly improved layout, flicker free.

v1.0
- First public release.
