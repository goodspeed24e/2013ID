function trans()
load USPStrainingdata;
fid=fopen('train.dat','a+');
traindata = 255*(traindata+1)/2;

for i = 1:7291
    a=reshape(traindata(i,:),16,16)';
    fwrite(fid,a,'int8');
end

fclose(fid);
