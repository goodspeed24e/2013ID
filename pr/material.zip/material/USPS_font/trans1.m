function transarg1()
load USPStrainingdata;
fid=fopen('traintarg.dat','a+');

for i = 1:7291
    a=reshape(traintarg(i,:),1,10);
    for j=1:10
        if a(1,j)==1    
            fwrite(fid,j-1,'int8');
        end
    end
end

fclose(fid);
