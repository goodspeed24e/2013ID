function f=tt(n)
%seach a number that less than 2000
f(1)=2;
k=1;
while f(k)<n
    f(k+1)=f(k)*2;
    k=k+1;
end
f