
US Postal Service Database
==========================

This database contains 7291 training patterns and 2007 test
patterns, with (16x16) resolution. All patterns are
0-9 digit representations.

USPS data were saved using [-1,+1] range to represent patterns
and the target is given by a number +1 in the correct position
of the target vector and -1 to the other classes.

The original files can be found on
http://www.kernel-machines.org/
The original binaries are in big endian format and must be
converted to run on intel platforms. No Matlab binaries
are provided.

The original files were converted to little endian and
saved in Matlab binary format (version 4). Matlab checks
binary files when reading to detect big or little endian.

TRAINING
========

The training data are organised by rows using a (7291x256)
matrix saved in Matlab binary format. Targets are stored
in a (7291x10) matrix.

  ------------------------------------------------
  Name            Size         Bytes  Class
  ------------------------------------------------
  cmap          256x3           6144  double array
  traindata    7291x256     14931968  double array
  traintarg    7291x10        583280  double array
  ------------------------------------------------
	Table 1: Variables in file USPStrainingdata.mat
	
USPS data were saved using [-1,+1] range to represent patterns.
If you want to use grey levels is interesting to represent them
using [0,255] range. This can be done like this:

% first, load all patterns
load USPStrainingdata;

% normalise the traindata in the [0,255] range
traindata = 255*(traindata+1)/2;

% assign [1 1 1] to white and [0 0 0] to black
traindata = round(255-traindata);

% plot a pattern (eg, the first pattern, six number)
i =  1;
image(reshape(traindata(i,:),16,16)');
colormap(cmap);
axis off;

The variable traintarg gives which digit each pattern represents.
This is done by assigning 1 to the correct class and -1 to
the other classes. For instance, for the previous pattern,
traintarg(1,:) will provide:

targets             0  1  2  3  4  5  6  7  8  9
traintarg(1,:) => [-1 -1 -1 -1 -1 -1  1 -1 -1 -1]
                                      ^
                                      |
                                      +--- number six

The colormap was created with the following commands:
% create a colormap for 256 Gary levels:
cmap = [0:255; 0:255; 0:255]';
cmap = cmap./255;

You can save memory using only uint8 to represent each pixel
instead double (eight times more memory is required) and a
single (7291x1) uint8 vector to represent the target class
(putting the digits 0-9 as targets)


TESTING
=======

The testing data are organised by rows using a (2007x256)
matrix saved in Matlab binary format. Targets are stored
in a (2007x10) matrix.

  ------------------------------------------------
  Name            Size         Bytes  Class
  ------------------------------------------------
  cmap         256x3           6144  double array
  testdata    2007x256      4110336  double array
  testtarg    2007x10        160560  double array
  ------------------------------------------------
	Table 2: Variables in file USPStestingdata.mat
	
All comments in previous section can be applied
to this section as well.


FULL DATABASE
=============

The file USPSfulldatabase.mat contains the full database
without distinction between training and testing data.

  ------------------------------------------------
  Name            Size         Bytes  Class
  ------------------------------------------------
  cmap         256x3           6144  double array
  patterns    9298x256     19042304  double array
  targets     9298x10        743840  double array
  ------------------------------------------------
	Table 3: Variables in file USPSfulldatabase.mat
	

COMMENTS
========

Marcelo Barros de Almeida
barros@cpdee.ufmg.br
16/May/2000

	