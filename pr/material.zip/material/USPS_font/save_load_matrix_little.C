/*****************************************************************************

 Save/load float's arrays in SN BINARY, SN PACKED, or SN ASCII format
     (PACKED: lower precision, one byte per float, range [-8,8])

 This code is partly based on SN code fragments - bs 9/96
 Rewrote it to automatically allocate the matrices - bs & franz 11/96

 save_load_matrix.C

 compile with: CC save_load_matrix.C -o save_load_matrix
           or: cc save_load_matrix.C -o save_load_matrix

 Functions are provided for use in the following situations:

  1. load an SN matrix into a statically allocated array
  2. load an SN matrix and automatically allocate dynamical storage for it
  3. save a statically allocated array into an SN matrix
  4. save a dynamically allocated array into an SN matrix

                   LOAD                               SAVE
                   stat.            dynam.         stat.          dynam.
------------------------------------------------------------------------------
vector           | load_in_vector   load_vector    save_vector    save_vector
matrix           | load_in_matrix   load_matrix    save_matrix    save_matrix2
array (ndim>2)   | load_in_array         -         save_array          -


For an example of their usage, look at the end of this file.
Note that when using C rather than C++, you may leave out
some of the casts in the examples.

******************************************************************************/

#include <stdio.h>

#ifdef __cplusplus
#include <stdlib.h>
#endif

/* WARNING : These three lines may change with your configuration */
#define Ftod(x) ((double)(x)) /* float to double */
#define Dtof(x) ((float) (x))
#define MAX_DIMS 16

/*
#define VECTOR_EXAMPLE
#define MATRIX_EXAMPLE
*/

#define USPS
/*
#define ARRAY_EXAMPLE
*/

/* Magic Numbers */

#define BINARY_MATRIX    (long)0x1e3d4c51               /* '\36=LQ' */
#define PACKED_MATRIX    (long)0x1e3d4c52               /* '\36=LR' */
#define ASCII_MATRIX     (long)0x2e4d4154               /*   '.MAT' */


/* FUNCTION PROTOTYPES */


/* general functions */
 /* used by the matrix and vector routines: */
 /* these routines are for ndim>2; ONLY for statically allocated arrays */
 void save_array(float *arr, char *s, int ndim, int *dim);
 void save_packed_array(float *arr, char *s, int ndim, int *dim);
 void save_ascii_array(float *arr, char *s, int ndim, int *dim);
 /* load into statically allocated storage */
 void load_in_array(float *arr, char *s, int ndim, int *dim);

/* 1-dim case */
 /* statically or dynamically allocated vectors */
 void save_vector(float *arr, char *s, int length);
 void save_ascii_vector(float *arr, char *s, int length);
 void save_packed_vector(float *arr, char *s, int length);
 /* dynamically allocates storage */
 float *load_vector(char *s, int *length);
 /* loads into statically allocated storage */
 void load_in_vector(float *arr, char *s, int length);

/* 2-dim case */
 /* if the matrices were NOT allocated dynamically, use the following */
 void save_matrix(float *arr, char *s, int dim0, int dim1);
 void save_ascii_matrix(float *arr, char *s, int dim0, int dim1);
 void save_packed_matrix(float *arr, char *s, int dim0, int dim1);
 /* if the matrices were allocated dynamically: */
 void save_matrix2(float **arr, char *s, int dim0, int dim1);
 void save_ascii_matrix2(float **arr, char *s, int dim0, int dim1);
 void save_packed_matrix2(float **arr, char *s, int dim0, int dim1);
 /* dynamically allocates storage */
 float **load_matrix(char *s, int *dim0, int *dim1);
 /* loads into statically allocated storage */
 void load_in_matrix(float *arr, char *s, int dim0, int dim1);


/* abort(s)
   Exits, printing the error message 's'
*/
void abort(char *s)
{
        fprintf(stderr,"SAVE_LOAD_MATRIX.C: %s\n",s);
        exit(10);
}

/*
 * read4(f), write4(f,x) Low level function to read or write 4-bytes
 * integers, with highest order byte at lowest address..... These functions
 * are useful for accessing file headers into machine independant files.
 */
long read4(FILE *f, long magic)
{
  unsigned char c[4];
  unsigned int i;

  if(magic == ASCII_MATRIX){
        fscanf(f, " %d", &i);
  }
  else{
    for (i = 0; i < 4; i++)
      if(!fread((char *) (c + i), (unsigned) 1, (int) 1, f))
        abort("Can't read header");

    i = (c[0] << 8) + c[1];
    i = (i << 8) + c[2];
    i = (i << 8) + c[3];
  }
  return i;
}


long read_magic(FILE *f)
{
  unsigned char c[4];
  unsigned int i;
  for (i = 0; i < 4; i++)
    if(!fread((char *) (c + i), (unsigned) 1, (int) 1, f))
      abort("Can't read header");

  i = (c[0] << 8) + c[1];
  i = (i << 8) + c[2];
  i = (i << 8) + c[3];

  return i;
}


/* write4(f,l)
   Writes the long l on file f , on 4 bytes, with high order byte first
*/
void write4(FILE *f, unsigned long l)
{
        char c[4];
        register int i;
        
        for(i=3;i>=0;i--)
        {       c[i] = l & 0xff;
                l >>= 8;
        }
        for(i=0;i<4;i++)
        {       if ( fwrite(c+i,1,1,f) != 1)
                        abort("can't write header");
        }
}


long read_header(FILE *f, int *pndim, int *dim)
{
  int i;
  long magic;

  magic = read_magic(f);
  *pndim =  read4(f, magic);
  if (*pndim<1 || *pndim>=MAX_DIMS)
    abort("number of dimensions out of range");
  for (i=0;i<*pndim;i++)
    dim[i] = read4(f, magic);
  while(i<3) {  /* for SN1 compatibility reasons */
    if(magic != ASCII_MATRIX)
      read4(f, magic); /* dummy */
    i++;
  }
  return magic;
}


void save_array(float *arr, char *s, int ndim, int *dim)
{
        register int i,size;
        FILE *f;
        
/*	if(ndim>1)
	printf("save_array WARNING: data may be lost if not contingent!\n");
*/
        size = 1;
        for( i=0; i<ndim; i++ )
                size *= dim[i];
        
        if (! (f = fopen(s,"w")))
                abort("can't open file");

        write4(f, BINARY_MATRIX);
        write4(f, (long)(ndim));
        for (i=0; i<ndim; i++ )
                write4(f, (long)(dim[i]));
        while(i++<3)
                write4(f, (long)1 );            /* SN1 compatibility */
                
        if (fwrite( arr, sizeof(float), size, f) != size)
                abort("can't write data");
        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
}


float **load_matrix(char *s, int *dim0, int *dim1)
{
        register int i,j,k,l,size;
        FILE *f;
        double x;
        float fx;
        unsigned char b;
        unsigned long int ii;
        float *pfi;


	long magic;
	float **arr;
	int read_size;
	int ndim = 0;
	int dim[2];
	
        if (! (f = fopen(s,"r")))
	  abort("can't open file for reading");
        magic = read_header(f, &ndim, dim);

	if (ndim != 2)
	  abort("Warning: expected and actual matrix dimensions differ,\n");

        size = 1;
        for( i=0; i<ndim; i++ )
          size *= dim[i];

	printf("read ");
	if(magic == BINARY_MATRIX)printf("binary");
	if(magic == PACKED_MATRIX)printf("packed");
	if(magic == ASCII_MATRIX)printf("ascii");
        printf(" matrix file header; ndim=%d (", ndim);
        for(i=0; i<ndim; i++){
	  printf(" %d ", dim[i]);
	  if(i<ndim-1)
	    printf("x");
	}
	printf (")\n");

	/* allocate 2-dim matrix */
	arr = (float**)malloc(dim[0]*sizeof(float*));
	if(arr == NULL){
		printf("Allocation error !\n");
		exit(0);
	}
	for(i=0;i<dim[0];i++){
	  arr[i] = (float*)malloc(dim[1]*sizeof(float));
		if(arr[i] == NULL){
			printf("Allocation error !\n");
			exit(0);
		}	
	}

 	if(magic == BINARY_MATRIX){
	  printf("loading binary data\n");

	  for(i=0;i<dim[0];i++){
	  	for(j=0;j<dim[1];j++){
	  				
	  				// converting big endian to little endian
	  				
            read_size = fread(&ii, sizeof(long int), 1, f);
            ii= 								(((ii&0xFF000000)>>24) | \
            						 				 ((ii&0x00FF0000)>>8)  | \
            						 				 ((ii&0x0000FF00)<<8)  | \
            						 				 ((ii&0x000000FF)<<24) );
            pfi = (float *) &ii;
            arr[i][j] = *pfi;            						 				           						 				

    	}

     }
	}

	if(magic == ASCII_MATRIX){
	  printf("loading ascii data\n");
	  for(i=0;i<dim[0];i++)
	    for(j=0;j<dim[1];j++){
	      fscanf(f, "%f\n",&fx);
	      arr[i][j] = fx;
	    }
	}

	if(magic == PACKED_MATRIX){
	  printf("loading packed data\n");
	  for(i=0;i<dim[0];i++)
	    for(j=0;j<dim[1];j++){       
	      if (fread( &b, sizeof(b), 1, f) != 1)
		         abort("can't read bytes");
	      if (b == 0x7f)
		         x = 8.0;
	      else if (b == 0x80)
		         x = -8.0;
	      else if (b < 0x7f)
		         x = (double)b / 16.0;
	      else if (b > 0x80)
		         x = (double)(256 - b) / -16.0;
	      arr[i][j] = Dtof(x);
	    }
	}


        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
	*dim0 = dim[0];
	*dim1 = dim[1];
	return arr;
}


float *load_vector(char *s, int *length)
{
        register int i,size;
        FILE *f;
        double x;
        float fx;
        unsigned char b;
	long magic;
	float *arr;
	int read_size;
	int ndim = 0;

        if (! (f = fopen(s,"r")))
	  abort("can't open file for reading");
        magic = read_header(f, &ndim, length);


	if (ndim != 1)
	  abort("Warning: expected and actual matrix dimensions differ,\n");

        size = *length;

	printf("read ");
	if(magic == BINARY_MATRIX)printf("binary");
	if(magic == PACKED_MATRIX)printf("packed");
	if(magic == ASCII_MATRIX)printf("ascii");
        printf(" vector file header; length=%d\n", *length);

	/* allocate 1-dim matrix */
	arr = (float*)malloc(size*sizeof(float));

        if(magic == BINARY_MATRIX){
	  printf("loading binary data\n");
          read_size = fread( arr, sizeof(float), size, f);
	  if (read_size != size){
            printf("expected size was %d floats, actual: %d\n",size,read_size);
            abort("can't read data");
	    }
	}


	if(magic == ASCII_MATRIX){
	  printf("loading ascii data\n");
	  for(i=0;i<size;i++){
	      fscanf(f, "%f\n",&fx);
	      arr[i] = fx;
	  }
	}

	if(magic == PACKED_MATRIX){
	  printf("loading packed data\n");
	  for(i=0;i<size;i++){       
	      if (fread( &b, sizeof(b), 1, f) != 1)
		         abort("can't read bytes");
	      if (b == 0x7f)
		         x = 8.0;
	      else if (b == 0x80)
		         x = -8.0;
	      else if (b < 0x7f)
		         x = (double)b / 16.0;
	      else if (b > 0x80)
		         x = (double)(256 - b) / -16.0;
	      arr[i] = Dtof(x);
	  }
	}

        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
	return arr;
}


void load_in_array(float *arr, char *s, int ndim, int *dim)
{
        register int i,size;
        FILE *f;
        double x;
        float fx;
        unsigned char b;
	long magic;
	int read_size;
	int read_ndim;
	int read_dim[MAX_DIMS];
	
        if (! (f = fopen(s,"r")))
	  abort("can't open file for reading");
        magic = read_header(f, &read_ndim, read_dim);
	if (ndim != read_ndim)
	  abort("matrix in file has number of dimensions different from statically allocated storage");

        size = 1;
        for( i=0; i<ndim; i++ ){
	  if (dim[i] != read_dim[i])
	    abort("matrix in file has different dimension sizes from statically allocated storage");
          size *= dim[i];
	}

	printf("read ");
	if(magic == BINARY_MATRIX)printf("binary");
	if(magic == PACKED_MATRIX)printf("packed");
	if(magic == ASCII_MATRIX)printf("ascii");
        printf(" matrix file header; ndim=%d (", ndim);
        for(i=0; i<ndim; i++){
	  printf(" %d ", dim[i]);
	  if(i<ndim-1)
	    printf("x");
	}
	printf (")\n");

        if(magic == BINARY_MATRIX){
	  printf("loading binary data\n");
	  read_size = fread( arr, sizeof(float), size, f);
	  if (read_size != size){
            printf("expected size was %d floats, actual: %d\n",size,read_size);
	    abort("can't read data");
	  }
	}

	if(magic == ASCII_MATRIX){
	  printf("loading ascii data\n");
	  for(i=0;i<size;i++){
	    fscanf(f, "%f\n",&fx);
	    arr[i] = fx;
	  }
	}

	if(magic == PACKED_MATRIX){
	  printf("loading packed data\n");
	  for(i=0;i<size;i++){       
	    if (fread( &b, sizeof(b), 1, f) != 1)
	      abort("can't read bytes");
	    if (b == 0x7f)
	      x = 8.0;
	    else if (b == 0x80)
	      x = -8.0;
	    else if (b < 0x7f)
	      x = (double)b / 16.0;
	    else if (b > 0x80)
	      x = (double)(256 - b) / -16.0;
	    arr[i] = Dtof(x);
	  }
	}


        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
}


void load_in_vector(float *arr, char *s, int length)
{
  load_in_array(arr, s, 1, &length);
}


void load_in_matrix(float *arr, char *s, int dim0, int dim1)
{
  int dim[2];
  dim[0] = dim0;
  dim[1] = dim1;
  load_in_array(arr, s, 2, dim);
}


void save_vector(float *arr, char *s, int length)
{
  save_array(arr, s, 1, &length);
}


void save_ascii_vector(float *arr, char *s, int length)
{
  save_ascii_array(arr, s, 1, &length);
}


void save_packed_vector(float *arr, char *s, int length)
{
  save_packed_array(arr, s, 1, &length);
}


void save_matrix(float *arr, char *s, int dim0, int dim1)
{
  int dim[2];

  dim[0] = dim0;
  dim[1] = dim1;

  save_array(arr, s, 2, dim);
}


void save_ascii_matrix(float *arr, char *s, int dim0, int dim1)
{
  int dim[2];

  dim[0] = dim0;
  dim[1] = dim1;

  save_ascii_array(arr, s, 2, dim);
}


void save_packed_matrix(float *arr, char *s, int dim0, int dim1)
{
  int dim[2];

  dim[0] = dim0;
  dim[1] = dim1;

  save_packed_array(arr, s, 2, dim);
}


void save_matrix2(float **arr, char *s, int dim0, int dim1)
{
  int dim[2];
  int ndim = 2;
  int write_size;
  register int i;
  FILE *f;

  dim[0] = dim0;
  dim[1] = dim1;

  if (! (f = fopen(s,"w")))
    abort("can't open file");

  write4(f, BINARY_MATRIX);
  write4(f, (long)(ndim));
  for (i=0; i<ndim; i++ )
    write4(f, (long)(dim[i]));
  while(i++<3)
    write4(f, (long)1 );            /* SN1 compatibility */

  for(i=0;i<dim[0];i++){
    write_size = fwrite(arr[i], sizeof(float), dim[1], f);
    if (write_size != dim[1])
      abort("can't write data: column length inconsistency"); 
  }

  fflush(f);
  if (ferror(f))
    abort("can't flush file");
  fclose(f);
}

void save_ascii_matrix2(float **arr, char *s, int dim0, int dim1)
{
  register int i,j;
  double x;
  FILE *f;
  int dim[2];
  int ndim = 2;

  dim[0] = dim0;
  dim[1] = dim1;
        

  if (! (f = fopen(s,"w")))
    abort("can't open file");
    
  write4(f, ASCII_MATRIX);
  fprintf(f, " %d", ndim);
  for (i=0; i<ndim; i++ )
    fprintf(f, " %d", dim[i]);
  fprintf(f, "\n");
      
  for (i=0;i<dim[0];i++)
    for(j=0;j<dim[1];j++){
      x = Ftod( arr[i][j] );
      fprintf(f, "%6.4f\n",x);
    }
  fflush(f);
  if (ferror(f))
    abort("can't flush file");
  fclose(f);
}

void save_packed_matrix2(float **arr, char *s, int dim0, int dim1)
{
  int dim[2];
  int ndim = 2;
  register int i, j;
  FILE *f;
  double x;
  unsigned char b;
 
  dim[0] = dim0;
  dim[1] = dim1;

  if (! (f = fopen(s,"w")))
    abort("can't open file");

  write4(f, PACKED_MATRIX);
  write4(f, (long)(ndim));
  for (i=0; i<ndim; i++ )
    write4(f, (long)(dim[i]));
  while(i++<3)
    write4(f, (long)1 );            /* SN1 compatibility */

  for(i=0;i<dim[0];i++)
    for(j=0;j<dim[1];j++){
                x = Ftod( arr[i][j] );                
                if (x >= 8.0)
                        b = 0x7f;
                else if (x <= -8.0)
                        b = 0x80;
                else
                        b = ( (int)(16.0 * x) & 0xff );
                        
                if (fwrite( &b, sizeof(b), 1, f) != 1)
                        abort("can't write bytes");
    }
  fflush(f);
  if (ferror(f))
    abort("can't flush file");
  fclose(f);
}


void save_packed_array(float *arr, char *s, int ndim, int *dim)
{
        register int i,size;
        double x;
        unsigned char b;
        FILE *f;
        
        size = 1;
        for( i=0; i<ndim; i++ )
                size *= dim[i];
        
        if (! (f = fopen(s,"w")))
                abort("can't open file");
        
        write4(f, PACKED_MATRIX);
        write4(f, (long)(ndim));
        for (i=0; i<ndim; i++ )
                write4(f, (long)(dim[i]));
        while(i++<3)
                write4(f, (long)1 );            /* SN1 compatibility */
        
        for (i=0; i<size; i++)
        {       
                x = Ftod( arr[i] );
                
                if (x >= 8.0)
                        b = 0x7f;
                else if (x <= -8.0)
                        b = 0x80;
                else
                        b = ( (int)(16.0 * x) & 0xff );
                        
                if (fwrite( &b, sizeof(b), 1, f) != 1)
                        abort("can't write bytes");
        }
        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
}



void save_ascii_array(float *arr, char *s, int ndim, int *dim)
{
        register int i,size;
        double x;
        FILE *f;
        

        size = 1;
        for( i=0; i<ndim; i++ )
                size *= dim[i];
        
        if (! (f = fopen(s,"w")))
                abort("can't open file");
        
        write4(f, ASCII_MATRIX);
        fprintf(f, " %d", ndim);
        for (i=0; i<ndim; i++ )
                fprintf(f, " %d", dim[i]);
        fprintf(f, "\n");
        
        for (i=0;i<size;i++)
        {       
                x = Ftod( arr[i] );
                fprintf(f, "%6.4f\n",x);
        }
        fflush(f);
        if (ferror(f))
                abort("can't flush file");
        fclose(f);
}



/* --------- HERE IS A PROGRAM EXAMPLE --------- */

#ifdef MATRIX_EXAMPLE

void main()
{

  float smatrix[2][3];
    /* for saving with save_vector, save_matrix, save_array */
  float **dmatrix;
    /* for saving with save_vector, save_matrix2 */
  float sloadmatrix[2][3];
    /* for loading with load_in_vector, load_in_matrix, load_in_array */
  float **dloadmatrix;
    /* for loading with load_vector, load_matrix */

  register int i,j;
  int dim[2];
  int save_dim[2];

  save_dim[0] = 2;
  save_dim[1] = 3;
        
  dmatrix = (float **)malloc(save_dim[0]*sizeof(float*));
  for(i=0;i<save_dim[0];i++)
    dmatrix[i] = (float*)malloc(save_dim[1]*sizeof(float));

  printf("toy matrix:");
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++){
      dmatrix[i][j] = 1 + j - i + (i+0.6) * 0.12342346;
      smatrix[i][j] = 1 + j - i + (i+0.6) * 0.12342346;
      printf("%f ", dmatrix[i][j]);
    }
  }
  printf("\n\n");

  save_matrix2       (dmatrix, "dbinary.mat", save_dim[0], save_dim[1]);
  save_packed_matrix2(dmatrix, "dpacked.mat", save_dim[0], save_dim[1]);
  save_ascii_matrix2 (dmatrix, "dascii.mat",  save_dim[0], save_dim[1]);
  save_matrix       ((float*)smatrix, "sbinary.mat", save_dim[0], save_dim[1]);
  save_packed_matrix((float*)smatrix, "spacked.mat", save_dim[0], save_dim[1]);
  save_ascii_matrix ((float*)smatrix, "sascii.mat",  save_dim[0], save_dim[1]);
  printf("saved 6 matrices\n");

  dloadmatrix = load_matrix("dbinary.mat", &dim[0], &dim[1]);
  printf("loaded binary dynamic matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", dloadmatrix[i][j]);}
  printf("\n\n");
  dloadmatrix = load_matrix ("dpacked.mat" , &dim[0], &dim[1]);
  printf("loaded packed dynamic matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", dloadmatrix[i][j]);}
  printf("\n\n");
  dloadmatrix = load_matrix ("dascii.mat", &dim[0], &dim[1]);
  printf("loaded ascii dynamic matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", dloadmatrix[i][j]);}
  printf("\n\n");

  load_in_matrix((float *)sloadmatrix, "dbinary.mat", dim[0], dim[1]);
  printf("loaded binary static matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", sloadmatrix[i][j]);}
  printf("\n\n");
  load_in_matrix ((float *)sloadmatrix, "dpacked.mat" , dim[0], dim[1]);
  printf("loaded packed static matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", sloadmatrix[i][j]);}
  printf("\n\n");
  load_in_matrix ((float *)sloadmatrix, "dascii.mat", dim[0], dim[1]);
  printf("loaded ascii static matrix:");
  for(i=0; i<dim[0]; i++){
    printf("\n"); for( j=0; j<dim[1]; j++) printf("%f ", sloadmatrix[i][j]);}
  printf("\n");
}

        
#endif


#ifdef VECTOR_EXAMPLE

void main()
{
        int i;
	float svector[3] = {0.1, -0.345, 7.3};
	float *dvector;
	float sloadvector[3];
	float *dloadvector;
        int dim = 3;
	int dloaddim=0;

	dvector = (float *)malloc(3 * sizeof(float));
	dvector[0] = 0.1;
	dvector[1] = -0.345;
	dvector[2] = 7.3;

	save_vector(svector, "sbinary.mat", dim);
	save_ascii_vector(svector, "sascii.mat", dim);
	save_packed_vector(svector, "spacked.mat", dim);

	save_vector(dvector, "dbinary.mat", dim);
	save_ascii_vector(dvector, "dascii.mat", dim);
	save_packed_vector(dvector, "dpacked.mat", dim);
	printf("saved 6 vectors\n");

	dloadvector = load_vector("dbinary.mat", &dloaddim);
	printf("loaded vector of length %d\n", dloaddim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", dloadvector[i]);
	printf ("\n");
	load_in_vector(sloadvector, "dascii.mat", dim);
	printf("loaded vector of length %d\n", dim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", sloadvector[i]);
	printf ("\n");
	dloadvector = load_vector("dpacked.mat", &dloaddim);
	printf("loaded vector of length %d\n", dloaddim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", dloadvector[i]);
	printf ("\n");
	load_in_vector(sloadvector, "dbinary.mat", dim);
	printf("loaded vector of length %d\n", dim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", sloadvector[i]);
	printf ("\n");
	dloadvector = load_vector("dascii.mat", &dloaddim);
	printf("loaded vector of length %d\n", dloaddim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", dloadvector[i]);
	printf ("\n");
	load_in_vector(sloadvector, "dpacked.mat", dim);
	printf("loaded vector of length %d\n", dim);
        for(i=0; i<3; i++)
	  printf("%4.2f ", sloadvector[i]);
	printf ("\ndone.\n");
}
#endif

#ifdef ARRAY_EXAMPLE

void main()
{
  float sarray[2][2][2];
    /* for saving with save_vector, save_matrix, save_array */
  float ***darray;
    /* for saving with save_vector, save_matrix2 */
  float sloadarray[2][2][2];
    /* for loading with load_in_vector, load_in_matrix, load_in_array */
  /*  float ***dloadarray; */
    /* for loading with load_vector, load_matrix */

  int i,j;
  /*  int dim[3]; */
  int save_dim[3] = {2, 2, 2};


  darray = (float ***)malloc(save_dim[0]*sizeof(float**));
  for(i=0;i<save_dim[0];i++){
    darray[i] = (float**)malloc(save_dim[1]*sizeof(float*));
    for(j=0;j<save_dim[1];j++)
      darray[i][j] = (float*)malloc(save_dim[2]*sizeof(float));
  }

  printf("toy 3-dim array:");
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++){
      darray[i][j][0] = 1 + j - i + (i+0.6) * 0.12342346;
      sarray[i][j][0] = 1 + j - i + (i+0.6) * 0.12342346;
      darray[i][j][1] = j - i + (i+0.6) * 0.1234;
      sarray[i][j][1] = j - i + (i+0.6) * 0.1234;
      printf("%f %f ; ", darray[i][j][0], darray[i][j][1]);
    }
  }
  printf("\n\n");

  save_array       ((float*)sarray, "sbinary.mat", 3, save_dim);
  save_packed_array((float*)sarray, "spacked.mat", 3, save_dim);
  save_ascii_array ((float*)sarray, "sascii.mat",  3, save_dim);
  printf("saved 6 arrays\n");

  load_in_array((float*)sloadarray, "sbinary.mat", 3, save_dim); 
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++)
      printf("%f %f ; ", sloadarray[i][j][0], sloadarray[i][j][1]);
  }
  printf("\n");
  load_in_array((float*)sloadarray, "sascii.mat", 3, save_dim); 
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++)
      printf("%f %f ; ", sloadarray[i][j][0], sloadarray[i][j][1]);
  }
  printf("\n");
  load_in_array((float*)sloadarray, "spacked.mat", 3, save_dim); 
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++)
      printf("%f %f ; ", sloadarray[i][j][0], sloadarray[i][j][1]);
  }
  printf("\n\n");

  printf("And now an example of what you must not do: save dynamically\n");
  printf("allocated general arrays with <save_array> - this will just save\n");
  printf("a contingent block of data starting from the pointer to the array.");
  printf("\nReloading then gives:\n");
  save_array((float*)darray, "dbinary.mat", 3, save_dim);
  load_in_array((float*)sloadarray, "dpacked.mat", 3, save_dim); 
  for(i=0; i<save_dim[0]; i++){
    printf("\n");
    for( j=0; j<save_dim[1]; j++)
      printf("%f %f ; ", sloadarray[i][j][0], sloadarray[i][j][1]);
  }
  printf("\n");

  printf("If you want, write a function <save_array2> that does the job.\n\n");
  printf("In addition, one could write a function that loads a general\n");
  printf("array and automatically allocates storage for it.\n");
  printf("An easy workaround would be to load the array into a vector,\n");
  printf("and return the dimensions.\n");

}
#endif

#ifdef USPS

// Modifications done to save ascii files
// arguments: input_file output_file
// works only with matrix files

void main(int argn, char** argv)
{
		float **dloadmatrix;
		int dim[2],i,j;
		FILE* fptr;

		dloadmatrix = load_matrix(argv[1], &dim[0], &dim[1]);
 
    printf("loaded binary dynamic matrix:");
    fptr = fopen(argv[2],"w");
    for(i=0; i<dim[0]; i++){
			for(j=0; j<dim[1]; j++)
	       fprintf(fptr,"%f\t", dloadmatrix[i][j]);
	  	fprintf(fptr,"\n");
	  }
	
		fclose(fptr);
}

#endif
