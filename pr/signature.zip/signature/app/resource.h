//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WiRecognition.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WIRECOGNITION_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_INPUT_TRAIN                 1000
#define IDC_INPUT_TEST                  1001
#define IDC_RECOGNITION                 1002
#define IDC_SAVE                        1003
#define IDC_SAVE_TEMP                   1003
#define IDC_PREV                        1004
#define IDC_NEXT                        1005
#define IDC_SHOW1                       1006
#define IDC_SHOW2                       1007
#define IDC_ABOUT                       1008
#define IDC_EXIT                        1009
#define IDC_PREPROCESS                  1010
#define IDC_RECOGNITION2                1010
#define IDC_LOAD_TEMP                   1010
#define IDC_SUBPIC                      1011
#define IDC_GENTEMP                     1011
#define IDC_PICTURE1                    1012
#define IDC_PICTURE2                    1013
#define IDC_COMPUTE                     1025
#define IDC_SCROLLBAR1                  1026
#define IDC_COMPUTE2                    1027
#define IDC_EDIT1                       1028
#define IDC_EDIT2                       1029
#define IDC_METHOD                      1030
#define IDC_RADIO_TEST                  1032
#define IDC_RADIO_TRAIN                 1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
